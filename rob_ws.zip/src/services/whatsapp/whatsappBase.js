export default class WhatsappWebBase {

  async sendMessage(phoneNumber, message) {
  }

  async sendImage(phoneNumber, base64Image, caption) {
  }
}

